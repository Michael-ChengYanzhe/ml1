The package needs are:
python 3.6 or above
numpy 1.15.4
graphviz 2.40.1
pydotplus 2.0.2
scikit-learn 0.20.1
matplotlib 3.0.2

The p1.py and p2.py are the script for the models in problem 1 and problem 2.
IT IS STRONGLY RECOMMENDED TO PUT IT IN TWO FOLDER AND RUN. SINCE IT WILL GENERATE MANY IMAGES.

Go to the directory, you may choose any from below:

1. In bash, run:(Recommend)
	./run.sh

	It is a bash file that can automately run .py file in the two folders.
	(If denied, use: sudo chmod 777 run.sh)

2. Goto each foler(P1 and P2), run:(Recommend)
	python p1.py
	python p2.py

3. Run:(Not recommend, but okay. The image file will have different name)
	python p1.py
	python p2.py

