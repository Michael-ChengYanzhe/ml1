python3 P1/p1.py
python3 P2/p2.py
